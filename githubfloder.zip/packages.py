#to divide the codes into modules & to organise the code ,code segregation is so important
#whenever __init__.py is in the floder then it is consider as package
