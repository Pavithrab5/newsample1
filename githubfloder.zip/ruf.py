def set_user1bal(self, user1bal):
    self.user1bal = 1900
obj=set_user1bal()
print(obj)


